this program use archive_dl to download FIXED Levels without issues in easy way !

just give him 3 things :

-Level name (optional you can enter any name you want)
*NOTE: you must be remove (&) and (:) symbols from Level name 

-Destination path (the path of folder you want to save levels on it) 

-HASH of level

to search levels and get the HASH use this website : https://maticzpl.xyz/lbpfind/

the # button is feature to load the last Destination path used by just click on it 
, it's useful when you run program and do you want search quickly
 without select Destination path every time.